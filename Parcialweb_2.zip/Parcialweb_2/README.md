ci_tut_crud
===========

Aplicacion CRUD con CodeIgniter

===============================

Tutorial hecho con el fin de mostrar cuan facil es desarrollar una aplicacion donde podemos
insertar, leer, modificar y eliminar informacion de una base de datos atraves de una simple
aplicacion programada en CodeIngniter.

Alejandro Acosta Barrios
