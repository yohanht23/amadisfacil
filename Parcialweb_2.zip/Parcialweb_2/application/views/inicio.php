<?php
	if(isset($persona_actualizar)){
		$id = '<p><input type="hidden" name="id" value="'.$this->uri->segment(3).'"></p>';
		$nombre= $persona_actualizar->nombre;
		$descripcion = $persona_actualizar->descripcion;
		$precio = $persona_actualizar->precio;
		$accion = 'actualizar';
	}
	else{
		$id='';
		$nombre='';
		$descripcion='';
		$precio='';
		$accion = 'insertar';
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <script src="https://code.jquery.com/jquery.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<title>Aplicacion con codeigniter</title>
    <style>
        body{
          background:#f7f7f7;
      }
      header{
          background:#fff;
      }
      .main{
          background:#fff;
          padding: 2rem 2.5rem 2rem;
          box-shadow: 0px 1px 1px #ccc;
      }
      .main .form-control, .main .btn{
          border-radius: 0px;
      }
      .main .col-xs-3{
          border-right: 1px solid #ddd;
          padding-right:3rem;
      }
      .main .col-xs-9{
          padding-left: 2.5rem;
      }
      .table td, .table th{
        text-align: center !important;
        vertical-align: middle !important;
    }
</style>
</head>
<body>
	<header>
		<div class="container">
			<h3>CRUD en codeigniter</h3>
		</div>
	</header>
	<br>
	<div class="container main">
		<div class="row">
			<div class="col-xs-3">
				<form action="<?php echo base_url(); ?>index.php/tutorial/<?php echo $accion; ?>" method="post">
				<?php echo $id; ?>
				<label>Nombre</label>
				<input type="text" class="form-control" placeholder='Inserte su nombre' name="nombre" value="<?php echo $nombre?>">
				<br>
				<label>Descripcion</label>
				<input type="text" class="form-control" placeholder='Comentario' name="descripcion" value="<?php echo $descripcion?>">
				<br>
				<label>Precio</label>
				<input type="text" class="form-control" placeholder='$0.00' name="precio" value="<?php echo $precio?>">
				<br>
				<button class="btn btn-success" type="sudmit">Guardar</button>
					
				</form>
			</div>		
	
				<div class="col-xs-9">
					<table class="table">
						<thead>
							<tr>
								<th>ID</th>
								<th>Nombre</th>
								<th>Descripcion</th>
								<th>Precio</th>
								<th>Accion</th>
							</tr>
						</thead>
						<tbody>
							<?php
							if(count($personas) >0){
								foreach ($personas as $persona) {
								?>
								<tr>
									<td><?php echo $persona->id; ?></td>
									<td><?php echo $persona->nombre; ?></td>
									<td><?php echo $persona->descripcion; ?></td>
									<td><?php echo $persona->precio; ?></td>

									<td>
										<a href="<?php echo base_url(); ?>index.php/tutorial/index/<?php echo $persona->id; ?>" class="btn btn-primary"><i class="fa fa-pencil"></i>Modificar</a>
										<a href="<?php echo base_url(); ?>index.php/tutorial/eliminar/<?php echo $persona->id; ?>" class="btn btn-danger"><i class="fa fa-remove"></i>Eliminar</a>
									</td>

								</tr>
								<?php

								}
							}else{
								?>
								<h4>No hay datos registrados</h4>
								<?php

							}
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>

</body>
</html>