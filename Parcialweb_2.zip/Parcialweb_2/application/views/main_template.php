<?php
	$this->load->view('plantillas/header');
	$this->load->view($main_content);
	$this->load->view('plantillas/footer');